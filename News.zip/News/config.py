class Config(object):
    SECRET_KEY = 'w9z$C&F)J@NcRfUjWnZr4u7x!A*G-KaPdSgVkYp2s5v8y/B?E(H+MbQeThWmZq'

    MONGODB_SETTINGS = {'db': 'News_App'}
