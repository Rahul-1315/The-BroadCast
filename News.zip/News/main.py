from application import app
# For running the requirement.txt file
#   pip install -r requirement.txt to install all packages!
